<?php

$myhost = "localhost";
$myuser = "id15742338_db0";
$mypass = "aRqkcR)u<Y_8-bE7";
$mydb = "id15742338_db1";
$key = "2147828743"; //Don't tuch this !

$con = mysqli_connect($myhost, $myuser, $mypass, $mydb);

if (mysqli_connect_errno())
{
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

?>